CanSatKit
===================

Main components of the CanSatKitLibrary are radio (SX1278) and BMP280 libraries.

.. toctree::
   radio.rst
   BMP280.rst